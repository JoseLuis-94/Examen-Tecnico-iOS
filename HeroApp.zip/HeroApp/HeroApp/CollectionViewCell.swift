//
//  CollectionViewCell.swift
//  HeroApp
//
//  Created by Graciela Sarahi Guerra Castillo on 18/02/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
